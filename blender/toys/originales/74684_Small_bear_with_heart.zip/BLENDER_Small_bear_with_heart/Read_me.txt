Name: Small simple bear with heart
Language (titles of objects ...): Slovak language
Author: Jakub Sumihora
Date created: 6. jun 2014
Date last modified: 8. jun 2014